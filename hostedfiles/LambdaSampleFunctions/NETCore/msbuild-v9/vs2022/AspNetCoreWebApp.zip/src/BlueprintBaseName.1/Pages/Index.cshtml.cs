﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BlueprintBaseName._1.Pages;

public class IndexModel : PageModel
{
    public void OnGet()
    {

    }
}
﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BlueprintBaseName._1.Pages;

public class HelpModel : PageModel
{
    public void OnGet()
    {

    }
}